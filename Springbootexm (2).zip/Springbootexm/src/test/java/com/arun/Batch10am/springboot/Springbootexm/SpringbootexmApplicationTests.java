package com.arun.Batch10am.springboot.Springbootexm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootexmApplicationTests {

	@Test
	void contextLoads() {
	}

}
