package com.arun.Batch10am.springboot.Springbootexm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootexmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootexmApplication.class, args);
	}

}
